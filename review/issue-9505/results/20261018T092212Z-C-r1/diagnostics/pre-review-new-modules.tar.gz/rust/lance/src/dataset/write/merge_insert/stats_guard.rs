// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright The Lance Authors

use std::sync::Arc;

use datafusion::common::{Result, Statistics, config::ConfigOptions, stats::Precision};
use datafusion::execution::TaskContext;
use datafusion::physical_plan::{
    DisplayAs, DisplayFormatType, ExecutionPlan, PhysicalExpr, PlanProperties,
    SendableRecordBatchStream,
    filter_pushdown::{FilterDescription, FilterPushdownPhase},
};

/// Withdraws unsafe size and cardinality hints only at the merge target boundary.
/// CardinalityEffect deliberately stays Unknown: the statistics registry must call us.
#[derive(Debug)]
pub(super) struct MergeTargetStatsGuardExec {
    input: Arc<dyn ExecutionPlan>,
}

impl MergeTargetStatsGuardExec {
    pub fn new(input: Arc<dyn ExecutionPlan>) -> Self {
        Self { input }
    }
}

impl DisplayAs for MergeTargetStatsGuardExec {
    fn fmt_as(&self, _: DisplayFormatType, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "MergeTargetStatsGuard: rows=Absent, bytes=Absent")
    }
}

impl ExecutionPlan for MergeTargetStatsGuardExec {
    fn name(&self) -> &str {
        "MergeTargetStatsGuardExec"
    }
    fn properties(&self) -> &Arc<PlanProperties> {
        self.input.properties()
    }
    fn children(&self) -> Vec<&Arc<dyn ExecutionPlan>> {
        vec![&self.input]
    }
    fn maintains_input_order(&self) -> Vec<bool> {
        vec![true]
    }
    fn with_new_children(
        self: Arc<Self>,
        children: Vec<Arc<dyn ExecutionPlan>>,
    ) -> Result<Arc<dyn ExecutionPlan>> {
        let [input]: [Arc<dyn ExecutionPlan>; 1] =
            children.try_into().map_err(|children: Vec<_>| {
                datafusion::common::DataFusionError::Internal(format!(
                    "StatsGuard expected 1 child, got {}",
                    children.len()
                ))
            })?;
        Ok(Arc::new(Self::new(input)))
    }
    fn partition_statistics(&self, partition: Option<usize>) -> Result<Arc<Statistics>> {
        let mut stats = self.input.partition_statistics(partition)?.as_ref().clone();
        stats.num_rows = Precision::Absent;
        stats.total_byte_size = Precision::Absent;
        Ok(Arc::new(stats))
    }
    fn execute(
        &self,
        partition: usize,
        context: Arc<TaskContext>,
    ) -> Result<SendableRecordBatchStream> {
        self.input.execute(partition, context)
    }
    fn repartitioned(
        &self,
        partitions: usize,
        config: &ConfigOptions,
    ) -> Result<Option<Arc<dyn ExecutionPlan>>> {
        Ok(self
            .input
            .repartitioned(partitions, config)?
            .map(|input| Arc::new(Self::new(input)) as Arc<dyn ExecutionPlan>))
    }
    fn gather_filters_for_pushdown(
        &self,
        _: FilterPushdownPhase,
        filters: Vec<Arc<dyn PhysicalExpr>>,
        _: &ConfigOptions,
    ) -> Result<FilterDescription> {
        FilterDescription::from_children(filters, &self.children())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow_array::record_batch;
    use datafusion::datasource::memory::MemorySourceConfig;
    use datafusion::physical_plan::collect;
    use datafusion::physical_plan::operator_statistics::StatisticsRegistry;

    #[tokio::test]
    async fn guard_survives_registry_and_preserves_rows() {
        let batch = record_batch!(
            ("key", Int64, [1, 2]),
            ("payload", Utf8, ["old-one", "old-two"])
        )
        .unwrap();
        let input =
            MemorySourceConfig::try_new_exec(&[vec![batch.clone()]], batch.schema(), None).unwrap();
        let plan: Arc<dyn ExecutionPlan> = Arc::new(MergeTargetStatsGuardExec::new(input));
        for registry in [
            StatisticsRegistry::new(),
            StatisticsRegistry::default_with_builtin_providers(),
        ] {
            let stats = registry.compute(plan.as_ref()).unwrap();
            assert_eq!(stats.base().num_rows, Precision::Absent);
            assert_eq!(stats.base().total_byte_size, Precision::Absent);
        }
        let stats = plan.partition_statistics(None).unwrap();
        assert_eq!(stats.num_rows, Precision::Absent);
        assert_eq!(stats.total_byte_size, Precision::Absent);
        let rebuilt = plan.clone().reset_state().unwrap();
        let output = collect(rebuilt, Arc::new(TaskContext::default()))
            .await
            .unwrap();
        assert_eq!(output, vec![batch]);
    }
}
