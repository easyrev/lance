#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/measure-environment.exit"' EXIT
space
for trial in 1 2 3 4 5; do
    for variant in "${variants[@]}"; do
        for module in pyarrow numpy; do
            run "$variant" "$disk/scripts/import-only.py" "$module" > "$raw/import-$module-$trial-$variant.txt"
        done
    done
done
for trial in 1 2 3 4 5; do
    for variant in base pure var matched-base matched-pure; do
        case $variant in
            matched-*)
                resolve "${variant#matched-}"
                original_so=$extension
                resolve "$variant"
                ln -sfn "$original_so" "$extension"
                printf '%s %s %s\n' "$trial" "$variant" "$(readlink -f "$extension")" >> "$raw/matched-extension-map.txt"
                ;;
        esac
        run "$variant" "$tools/take-rss-stages.py" "$task/data/utf8-1page" 128 --dataset-rows 25000 --take-only > "$raw/attribution-$trial-$variant.json"
    done
done
