#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/environment.exit"' EXIT
space
for variant in "${variants[@]}"; do
    resolve "$variant"
    pip --python "$environment/bin/python" freeze --all > "$raw/pip-freeze-$variant.txt"
    "$environment/bin/python" -V > "$raw/python-version-$variant.txt"
    case $variant in
        base|pure|var) expected_hash=$(awk -v extension="$extension" '$2==extension {print $1}' "$archive/resume/raw/"{prior-extensions,extension-pure,extension-var}.sha256) ;;
        final|final-b) expected_hash=$(awk '{print $1}' "$archive2/raw/extension-$variant.sha256") ;;
    esac
    printf '%s  %s\n' "$expected_hash" "$extension" > "$raw/extension-$variant.sha256"
    sha256sum -c "$raw/extension-$variant.sha256"
done
resolve pure
pure_env=$environment
pure_so=$extension
mkdir -p "$disk/matched-project"
git -C "$checkout" archive HEAD python/python/lance | tar -x -C "$disk/matched-project"
(
    cd "$checkout/python"
    UV_PROJECT_ENVIRONMENT="$disk/venv-matched" uv sync --frozen --python 3.12 --no-install-project
) > "$raw/uv-sync-matched.log" 2>&1
site=$disk/venv-matched/lib/python3.12/site-packages
cp -a "$pure_env"/lib/python3.12/site-packages/pylance-*.dist-info "$site/"
printf '%s\n' "$disk/matched-project/python/python" > "$site/pylance.pth"
python3 - "$site" "$disk" <<'PY'
import json
import sys
from pathlib import Path
site, disk = map(Path, sys.argv[1:])
[dist_info] = site.glob("pylance-*.dist-info")
direct_url = dist_info / "direct_url.json"
data = json.loads(direct_url.read_text())
data["url"] = (disk / "matched-project/python").as_uri()
direct_url.write_text(json.dumps(data))
PY
resolve matched-pure
ln -s "$pure_so" "$extension"
pip --python "$environment/bin/python" freeze --all > "$raw/pip-freeze-matched.txt"
diff -u <(sed '/^#/d; /^-e /d' "$raw/pip-freeze-pure.txt") <(sed '/^#/d; /^-e /d' "$raw/pip-freeze-matched.txt") > "$raw/matched-package-diff.txt"
git -C /root/lance/repo diff --exit-code cb8c25692 16e3c99b1 -- python/python/lance > "$raw/python-sources-base-pure.diff"
