#!/usr/bin/env bash
set -euo pipefail
disk=/root/lance/tmp/shared-buffer-followup
raw=$disk/raw
task=/dev/shm/lance-10526/shared-buffer-followup
old=/dev/shm/lance-10526/ipc
tools=/root/lance/tmp/shared-buffer-tools
archive=/root/lance/tmp/review-fullzip-variable-shared-buffers/review/issue-10526
archive2=/root/lance/tmp/10526-review/review/issue-10526/linux-64cpu/third-column
prior=/root/lance/tmp/10526-review/review/issue-10526/linux-64cpu
trap 'status=$?; echo "$status" > "$raw/prepare.exit"' EXIT
export LANCE_CPU_THREADS=64 TMPDIR=$disk/tmp UV_CACHE_DIR=/root/lance/cache/uv
unset LANCE_FILE_WRITER_MAX_PAGE_BYTES
df -h / /dev/shm | tee "$raw/space.log"
for mount in / /dev/shm; do (( $(df -B1 --output=avail "$mount" | tail -1) >= 10737418240 )); done
mkdir -p "$task/data" "$task/ipc"
base=/root/lance/base/python/.venv/bin/python
final=/root/lance/final/python/.venv/bin/python
"$base" -B "$tools/prepare.py" generate "$task/ipc/binary-zstd-medium.arrow" 99650 8192 32768
"$base" -B "$tools/prepare.py" generate "$task/ipc/mixed.arrow" 16000 8192 16384 --mixed
expected_ipc() {
    local path=$1 filename=${1##*/}
    local hash
    hash=$(awk -v name="/$filename" 'index($2,name)==length($2)-length(name)+1 {print $1}' "$archive/raw/inputs.sha256")
    printf '%s  %s\n' "$hash" "$path"
}
{
    expected_ipc "$old/wide-unique.arrow"
    expected_ipc "$old/wide-repeated.arrow"
    expected_ipc "$old/wide-clustered.arrow"
    expected_ipc "$task/ipc/binary-zstd-medium.arrow"
    expected_ipc "$task/ipc/mixed.arrow"
} > "$raw/inputs.sha256"
sha256sum -c "$raw/inputs.sha256"
write_main() {
    local name=$1 input=$2
    shift 2
    "$base" -B "$tools/prepare.py" write "$input" "$task/data/$name" "$@" > "$raw/write-$name.json"
}
write_main utf8-1page "$old/wide-unique.arrow"
write_main binary-medium-default "$task/ipc/binary-zstd-medium.arrow" --stream
write_main binary-zstd-medium "$task/ipc/binary-zstd-medium.arrow" --stream --zstd
write_main mixed "$task/ipc/mixed.arrow" --stream
for name in utf8-1page binary-medium-default binary-zstd-medium mixed; do
    expected=$archive/raw/pages-$name.json
    if [[ $name == binary-medium-default ]]; then expected=$archive/resume/raw/pages-$name.json; fi
    pages=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["pages"])' "$expected")
    "$base" -B "$prior/decode-followup/inspect_data.py" "$task/data/$name" "$pages" > "$raw/pages-$name.json"
    diff -u "$expected" "$raw/pages-$name.json"
done
export LANCE_BENCH_PROTO_DIR=/root/lance/final/protos
for name in wide-repeated wide-clustered; do
    "$final" -B "$prior/bench.py" measure "$old/$name.arrow" "$task" --writers 1 --file-stats --keep "$task/data/$name" > "$raw/write-$name.json"
    expected=$archive2/raw/phase2-pages-$name-final.json
    pages=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["pages"])' "$expected")
    "$final" -B "$prior/decode-followup/inspect_data.py" "$task/data/$name" "$pages" > "$raw/pages-$name.json"
    diff -u "$expected" "$raw/pages-$name.json"
done
