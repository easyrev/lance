#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/noise.exit"' EXIT
space
input=$task/data/binary-zstd-medium
for trial in 1 2 3 4 5 6 7; do
    for variant in pure var; do
        run "$variant" "$tools/scan.py" "$input" 99650 > "$raw/noise-ab-$trial-$variant.json"
    done
done
for group in a1 a2; do
    for trial in 1 2 3 4 5 6 7; do
        run pure "$tools/scan.py" "$input" 99650 > "$raw/noise-$group-$trial-pure.json"
    done
done
