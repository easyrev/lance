import csv
import json
import statistics
import sys
from pathlib import Path

raw = Path(sys.argv[1])
variants = ("base", "pure", "var", "final", "final-b")


def summarize(values):
    return statistics.median(values), min(values), max(values)


def display(triple):
    value, low, high = triple
    return f"{value:.2f} [{low:.2f}–{high:.2f}]"


def emit_table(headers, rows):
    print("| " + " | ".join(headers) + " |")
    print("|" + "|".join("---" for _ in headers) + "|")
    for row in rows:
        print("| " + " | ".join(str(value) for value in row) + " |")


print("# 三项复核")
print()
print("## 环境对照")
print()
freezes = {}
for variant in (*variants, "matched"):
    lines = (raw / f"pip-freeze-{variant}.txt").read_text().splitlines()
    packages = frozenset(line for line in lines if line and not line.startswith(("#", "-e ")))
    edits = [line.removeprefix("-e ") for line in lines if line.startswith("-e ")]
    assert len(edits) == 1
    freezes[variant] = (packages, edits[0])
print("使用系统 pip 的 `--python <venv>/bin/python freeze --all`。")
print()
emit_table(["环境", "非 editable 条目数", "editable pylance 来源"], [
    (variant, len(packages), f"`{source}`") for variant, (packages, source) in freezes.items()
])
print()
reference = freezes["base"][0]
print("以 base 为参照，非 editable 条目差异如下。")
print()
for variant in (*variants[1:], "matched"):
    current = freezes[variant][0]
    print(f"- {variant} 新增 {sorted(current-reference)}，缺少 {sorted(reference-current)}")
print()
print("以下 RSS 单位为 MiB，格式为中位数 [min–max]。每环境和导入方式各 5 个新进程。")
print()
rows = []
for variant in variants:
    cells = [variant]
    for module in ("pyarrow", "numpy"):
        result = [(raw / f"import-{module}-{i}-{variant}.txt").read_text().split() for i in range(1, 6)]
        assert all(row[0] == module for row in result)
        assert len({row[2] for row in result}) == 1
        cells.append(display(summarize([int(row[1]) / 1024 for row in result])))
    rows.append(cells)
emit_table(["环境", "import pyarrow", "import numpy"], rows)
print()
print("pyarrow 进程只显式导入 pyarrow，numpy 是它的传递导入。所有采样进程在采样点均未导入 lance。")
print()
rows = []
summary = {}
for variant in ("base", "pure", "var", "matched-base", "matched-pure"):
    result = [json.loads((raw / f"attribution-{i}-{variant}.json").read_text()) for i in range(1, 6)]
    assert all(row["indices"] == result[0]["indices"] for row in result)
    measurements = [
        summarize([row[key] / 1024 for row in result])
        for key in ("import_peak_rss_kib", "open_peak_rss_kib", "process_peak_rss_kib")
    ]
    summary[variant] = measurements
    rows.append([variant, *(display(metric) for metric in measurements)])
emit_table(["单页构建", "import lance 后", "dataset open 后", "首次 take(128) 后"], rows)
print()
emit_table(["比较", "import 后差值", "open 后差值", "首次 take 后差值"], [
    [f"{b} − {a}", *(f"{v[0]-u[0]:+.2f}" for u, v in zip(summary[a], summary[b]))]
    for a, b in (("base", "pure"), ("base", "var"), ("matched-base", "matched-pure"),
                 ("base", "matched-base"), ("pure", "matched-pure"))
])
print()
print("## 快路径覆盖")
print()
rows = []
for variant, names in (
    ("pure", ("binary-medium-default", "mixed", "binary-zstd-medium")),
    ("var", ("binary-medium-default", "mixed", "binary-zstd-medium")),
    ("final-b", ("wide-repeated", "wide-clustered")),
):
    for name in names:
        for op in ("take", "scan"):
            with (raw / f"probe-{variant}-{name}-{op}.csv").open() as stream:
                events = csv.reader(line for line in stream if line.strip() and not line.startswith("#"))
                counts = {}
                for row in events:
                    assert float(row[4]) >= 99.9, row
                    counts[row[2].rsplit("_", 1)[1]] = int(row[0])
            rows.append((variant, name, op, counts["fast"], counts["concat"]))
emit_table(["构建", "数据集", "操作", "decode_variable_into", "concat_decoded_arrays"], rows)
print()
print("## Scan 峰值 RSS")
print()
rows = []
noise = {}
for group, variant in (("ab", "pure"), ("ab", "var"), ("a1", "pure"), ("a2", "pure")):
    results = [json.loads((raw / f"noise-{group}-{i}-{variant}.json").read_text()) for i in range(1, 8)]
    assert all(row["rows"] == 99650 for row in results)
    summary = summarize([row["process_peak_rss_kib"] / 1024 for row in results])
    noise[(group, variant)] = summary[0]
    rows.append((group, variant, display(summary)))
emit_table(["序列", "构建", "峰值 RSS MiB（每组 7 进程）"], rows)
print()
for title, before, after in (
    ("A/B，pure-B-var − pure-B", ("ab", "pure"), ("ab", "var")),
    ("A/A，第二组 − 第一组", ("a1", "pure"), ("a2", "pure")),
):
    previous, latest = noise[before], noise[after]
    print(f"- {title}，中位数差 {latest-previous:+.2f} MiB（{(latest/previous-1)*100:+.2f}%）。")
