import resource
import sys

requested = sys.argv[1]
loaded = __import__(requested)
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
assert "lance" not in sys.modules
assert "pyarrow" not in sys.modules or requested == "pyarrow"
print(requested, peak, loaded.__version__, int("numpy" in sys.modules))
