#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/run.exit"' EXIT
for step in measure-environment probe noise; do
    printf '%s %s\n' "$(date -u +%FT%TZ)" "$step"
    bash "$disk/scripts/$step.sh"
done
perf probe -l > "$raw/probe-list-after.txt"
