#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
group=lance10526followup
active=()
cleanup() {
    local status=$?
    for event in "${active[@]}"; do perf probe --del "$event" >> "$raw/probe-cleanup.log" 2>&1 || true; done
    echo "$status" > "$raw/probe.exit"
}
trap cleanup EXIT
space
for variant in pure var final-b; do
    resolve "$variant"
    nm -an --defined-only "$extension" | awk '/21concat_decoded_arrays$|25VariableFullZipDecodeTask.*20decode_variable_into$/' > "$raw/symbols-$variant.txt"
    readelf -lW "$extension" > "$raw/program-headers-$variant.txt"
    events=()
    for kind in concat fast; do
        pattern='21concat_decoded_arrays$'
        if [[ $kind == fast ]]; then pattern='25VariableFullZipDecodeTask.*20decode_variable_into$'; fi
        addr=$(awk -v pattern="$pattern" '$3 ~ pattern {print $1}' "$raw/symbols-$variant.txt")
        [[ $addr =~ ^[a-f0-9]+$ ]]
        file_addr=$(python3 - "$addr" "$raw/program-headers-$variant.txt" <<'PY'
import sys
addr = int(sys.argv[1], 16)
with open(sys.argv[2]) as stream:
    for line in stream:
        columns = line.split()
        if columns and columns[0] == "LOAD":
            offset, virtual, _, size = (int(x, 16) for x in columns[1:5])
            if virtual <= addr < virtual + size:
                print(hex(addr - virtual + offset))
                break
    else:
        raise RuntimeError("Symbol is outside a file-backed LOAD segment")
PY
)
        event=$group:${variant//-/_}_$kind
        perf probe --no-inlines -x "$extension" --add "$event=$file_addr" >> "$raw/probe-registration.log" 2>&1
        printf '%s\t%s\t%s\n' "$event" "$addr" "$file_addr" >> "$raw/probe-addresses.tsv"
        active+=("$event")
        events+=(-e "$event")
    done
    sets=(binary-medium-default mixed binary-zstd-medium)
    if [[ $variant == final-b ]]; then sets=(wide-repeated wide-clustered); fi
    for name in "${sets[@]}"; do
        case $name in
            binary-*) rows=99650 ;;
            mixed) rows=16000 ;;
            wide-repeated) rows=8000 ;;
            wide-clustered) rows=25000 ;;
        esac
        (
            cd "$checkout/python"
            perf stat -x , --no-big-num -o "$raw/probe-$variant-$name-take.csv" "${events[@]}" -- \
                "$environment/bin/python" -B "$tools/take.py" "$task/data/$name" 128 --dataset-rows "$rows" --take-only > "$raw/probe-$variant-$name-take.json"
            perf stat -x , --no-big-num -o "$raw/probe-$variant-$name-scan.csv" "${events[@]}" -- \
                "$environment/bin/python" -B "$tools/scan.py" "$task/data/$name" "$rows" > "$raw/probe-$variant-$name-scan.json"
        )
    done
done
