#!/usr/bin/env bash
set -euo pipefail
disk=/root/lance/tmp/shared-buffer-followup
raw=$disk/raw
task=/dev/shm/lance-10526/shared-buffer-followup
previous=/root/lance/tmp/shared-buffer-build
tools=/root/lance/tmp/shared-buffer-tools
archive=/root/lance/tmp/review-fullzip-variable-shared-buffers/review/issue-10526
archive2=/root/lance/tmp/10526-review/review/issue-10526/linux-64cpu/third-column
export LANCE_CPU_THREADS=64 TMPDIR=$disk/tmp UV_CACHE_DIR=/root/lance/cache/uv
unset LANCE_FILE_WRITER_MAX_PAGE_BYTES
variants=(base pure var final final-b)
space() {
    df -h / /dev/shm >> "$raw/space.log"
    for mount in / /dev/shm; do (( $(df -B1 --output=avail "$mount" | tail -1) >= 10737418240 )); done
}
resolve() {
    local variant=$1
    case $variant in
        base|final) checkout=/root/lance/$variant; environment=$checkout/python/.venv ;;
        pure|var) checkout=/root/lance/shared-buffer-$variant; environment=$previous/venv-$variant ;;
        final-b) checkout=/root/lance/shared-buffer-final; environment=$previous/venv-final-b ;;
        matched-base|matched-pure) checkout=$disk/matched-project; environment=$disk/venv-matched ;;
    esac
    extension=$checkout/python/python/lance/lance.abi3.so
}
run() (
    resolve "$1"
    shift
    cd "$checkout/python"
    exec "$environment/bin/python" -B "$@"
)
