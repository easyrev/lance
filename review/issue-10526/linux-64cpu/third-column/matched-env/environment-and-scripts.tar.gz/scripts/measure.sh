#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/measure.exit"' EXIT
space
for item in environment data; do
    until [[ -s $raw/$item.exit ]]; do sleep 10; done
    [[ $(cat "$raw/$item.exit") == 0 ]]
done
mkdir -p "$raw"/{imports,p1,p2}
for trial in 1 2 3 4 5; do
    for variant in base pure final final-b; do
        run "$variant" -c 'import resource; import lance; print(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)' > "$raw/imports/$variant-$trial.txt"
    done
done
measure() {
    local phase=$1 dataset=$2 rows=$3 op=$4 cohort=$5 trial=$6 variant=$7 source=$7
    local target="$raw/$phase/$dataset-$op-$cohort-$trial-$variant.jsonl"
    if [[ -s $target ]]; then return; fi
    local path=$task/$phase/$dataset
    if [[ $phase == p2 ]]; then
        if [[ $variant == final-b ]]; then source=final; fi
        path=$path/$source
    fi
    local -a args
    if [[ $phase == p2 && ( $op == scan || $op == take ) ]]; then
        args=("$prior/bench.py" read "$path" "$old/$dataset.arrow" "$op")
    elif [[ $op == scan ]]; then
        args=("$tools/scan.py" "$path" "$rows")
    else
        args=("$tools/take.py" "$path" "${op#repeat}" --dataset-rows "$rows" --take-only --repeat 20)
    fi
    run "$variant" "${args[@]}" > "$target.pending"
    mv -- "$target.pending" "$target"
}
run_case() {
    local phase=$1 dataset=$2 rows=$3 op=$4 n=5
    shift 4
    local -a builds=("$@")
    if [[ $op == scan ]]; then n=7; fi
    for cohort in primary repeat; do
        space
        printf '%s %s %s %s %s\n' "$(date -u +%FT%TZ)" "$phase" "$dataset" "$op" "$cohort"
        for ((trial=1; trial<=n; trial++)); do
            for build in "${builds[@]}"; do measure "$phase" "$dataset" "$rows" "$op" "$cohort" "$trial" "$build"; done
        done
    done
}
datasets=(utf8-1page utf8-zstd-25k utf8-zstd-8k binary-zstd-varlen binary-random-varlen binary-zstd-medium binary-medium-default mixed)
row_counts=(25000 25000 8000 12000 12000 99650 99650 16000)
for i in "${!datasets[@]}"; do
    for op in scan repeat128 repeat1024; do
        run_case p1 "${datasets[$i]}" "${row_counts[$i]}" "$op" base pure
    done
done
datasets=(wide-unique wide-unique-8k wide-low-card wide-repeated wide-template wide-clustered wide-mixed wide-constant narrow)
row_counts=(25000 8000 25000 8000 25000 25000 25000 25000 10000000)
for i in "${!datasets[@]}"; do
    for op in scan take; do
        run_case p2 "${datasets[$i]}" "${row_counts[$i]}" "$op" base final final-b
    done
done
for op in repeat128 repeat1024; do run_case p2 wide-unique 25000 "$op" base final final-b; done
