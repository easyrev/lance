#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/environment.exit"' EXIT
space
template=/root/lance/tmp/shared-buffer-build/venv-pure/lib/python3.12/site-packages
previous=/root/lance/tmp/shared-buffer-followup/raw
for variant in base pure final final-b; do
    space
    resolve "$variant"
    sha256sum -c "$previous/extension-$variant.sha256" > "$raw/extension-$variant.check"
    cp "$previous/extension-$variant.sha256" "$raw/"
    git -C "$checkout" rev-parse HEAD > "$raw/commit-$variant.txt"
    (
        cd /root/lance/shared-buffer-pure/python
        UV_PROJECT_ENVIRONMENT="$environment" uv sync --frozen --python 3.12 --no-install-project --no-build
    ) > "$raw/uv-$variant.log" 2>&1
    site=$environment/lib/python3.12/site-packages
    cp -a "$template"/pylance-*.dist-info "$site/"
    printf '../../../project/python/python\n' > "$site/pylance.pth"
    mkdir -p "$environment/project"
    git -C /root/lance/repo archive 16e3c99b1 python/python/lance | tar -x -C "$environment/project"
    package=$environment/project/python/python/lance
    ln -s "$extension" "$package/lance.abi3.so"
    pip --python "$environment/bin/python" freeze --all > "$raw/freeze-$variant.txt"
    "$environment/bin/python" -V > "$raw/python-$variant.txt"
    readlink -f "$environment/bin/python" >> "$raw/python-$variant.txt"
    run "$variant" -c 'import lance.lance; from pathlib import Path; print(Path(lance.lance.__file__).resolve())' > "$raw/import-extension-$variant.txt"
    [[ $(cat "$raw/import-extension-$variant.txt") == "$extension" ]]
    (cd "$site"; find . -type f ! -path '*/__pycache__/*' -print0 | sort -z | xargs -0 sha256sum) > "$raw/site-$variant.sha256"
    (cd "$package"; find . -type f -print0 | sort -z | xargs -0 sha256sum) > "$raw/package-$variant.sha256"
done
python3 "$disk/scripts/audit-env.py" "$disk" > "$raw/environment-match.txt"
