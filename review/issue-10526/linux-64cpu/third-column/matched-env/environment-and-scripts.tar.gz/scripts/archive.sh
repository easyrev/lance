#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
[[ $(cat "$raw/measure.exit") == 0 ]]
r1=$archive/matched-env
r2=$third/matched-env
mkdir -p "$r1" "$r2"
for phase in p1 p2; do
    target=$r1
    if [[ $phase == p2 ]]; then target=$r2; fi
    cp "$disk/reports/$phase-summary.md" "$target/summary.md"
    cp "$disk/reports/$phase-aa.md" "$target/aa.md"
    cp "$disk/reports/$phase-classified.md" "$target/classified.md"
    cp "$disk/reports/$phase-audit.txt" "$target/audit.txt"
    cp "$disk/reports/environment.md" "$target/"
    cp "$disk/handoff.md" "$target/"
    cp "$disk/reports/$phase-readme.md" "$target/README.md"
    tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -C "$disk" -cf - "raw/$phase" | gzip -n > "$target/timed-processes.tar.gz"
done
entries=(raw/environment.log raw/environment-match.txt raw/environment.exit raw/environment-initial.exit raw/measure.log raw/measure.exit raw/measure-initial.exit raw/measure-initial.log raw/space.log raw/data raw/data.log raw/data.exit raw/imports scripts reused)
for variant in base pure final final-b; do
    entries+=("raw/freeze-$variant.txt" "raw/python-$variant.txt" "raw/commit-$variant.txt" "raw/extension-$variant.sha256" "raw/extension-$variant.check" "raw/import-extension-$variant.txt" "raw/site-$variant.sha256" "raw/package-$variant.sha256" "raw/uv-$variant.log")
done
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner --exclude=__pycache__ -C "$disk" -cf - "${entries[@]}" | gzip -n > "$r1/environment-and-scripts.tar.gz"
cp "$r1/environment-and-scripts.tar.gz" "$r2/"
for target in "$r1" "$r2"; do
    python3 - "$disk" "$target" <<'PY'
import sys
import tarfile
from pathlib import Path
disk, target = map(Path, sys.argv[1:])
for packed in target.glob("*.tar.gz"):
    with tarfile.open(packed) as archive:
        for entry in archive.getmembers():
            if entry.isfile():
                assert archive.extractfile(entry).read() == (disk / entry.name).read_bytes(), entry.name
PY
done
printf '\n## PR 数字的匹配环境复测\n\n[matched-env](matched-env/README.md)保留独立的正式组和同构建 A/A 组，并给出噪声门槛及每项判定。此前各轮的原始样本和汇总保留原样。\n' >> "$archive/README.md"
for target in "$archive" "$r2"; do
    (cd "$target"; find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS; sha256sum -c --quiet SHA256SUMS)
done
