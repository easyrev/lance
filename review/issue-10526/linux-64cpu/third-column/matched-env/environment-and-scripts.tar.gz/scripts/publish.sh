#!/usr/bin/env bash
set -euo pipefail
cd /root/lance/repo
skill=/root/.agents/skills/issue-branches/scripts
base1=perf/fullzip-variable-shared-buffers
base2=perf/10526-wide-value-page-split
r1=review/fullzip-variable-shared-buffers
r2=review/10526-wide-value-page-split
[[ $(git remote get-url --push origin) == https://github.com/easyrev/lance ]]
[[ $(git rev-parse "$base1") == 16e3c99b1faa6014c17e33331f35cce726302243 ]]
[[ $(git rev-parse "$base2") == d0020f4291a0cb18790ac731df7c24890a169ca1 ]]
git diff --name-only 9bc307994 "$r2" | awk '
    !/^review\/issue-10526\/linux-64cpu\/third-column\/matched-env\// { print; mismatch = 1 }
    END { exit mismatch }
'
bash "$skill/check_separation.sh" "$base1" "$r1" 10526
bash "$skill/check_separation.sh" "$base2" "$r2" 10526
bash "$skill/check_commit_refs.sh" cb8c25692 "$base1" "$base2" "$r1" "$r2"
git push --atomic origin "$r1" "$r2"
for ref in "$r1" "$r2"; do
    actual=$(git ls-remote --heads origin "refs/heads/$ref" | cut -f1)
    [[ $actual == "$(git rev-parse "$ref")" ]]
    printf 'Verified %s %s\n' "$ref" "$actual"
done
[[ -z $(git ls-remote --heads origin "refs/heads/$base1") ]]
[[ $(git ls-remote --heads origin "refs/heads/$base2" | cut -f1) == "$(git rev-parse "$base2")" ]]
git fetch origin "refs/heads/$r1:refs/remotes/origin/$r1" "refs/heads/$r2:refs/remotes/origin/$r2"
bash "$skill/check_separation.sh" "$base1" "origin/$r1" 10526
bash "$skill/check_separation.sh" "$base2" "origin/$r2" 10526
