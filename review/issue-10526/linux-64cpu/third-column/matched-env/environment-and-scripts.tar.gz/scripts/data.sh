#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
trap 'status=$?; echo "$status" > "$raw/data.exit"' EXIT
space
mkdir -p "$task"/{ipc,p1,p2} "$raw/data"
main=/root/lance/base/python/.venv/bin/python
final=/root/lance/final/python/.venv/bin/python
check() {
    local label=$1 path=$2 expected=$3 reader=$4
    local pages
    pages=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["pages"])' "$expected")
    "$reader" -B "$prior/decode-followup/inspect_data.py" "$path" "$pages" > "$raw/data/pages-$label.json"
    diff -u "$expected" "$raw/data/pages-$label.json"
}
for name in utf8-1page binary-zstd-medium binary-medium-default mixed; do
    ln -s "$reuse/$name" "$task/p1/$name"
done
"$main" -B "$tools/prepare.py" write "$old/wide-unique.arrow" "$task/p1/utf8-zstd-25k" --stream > "$raw/data/write-utf8-zstd-25k.json"
"$main" -B "$tools/prepare.py" write "$old/wide-unique-8k.arrow" "$task/p1/utf8-zstd-8k" --stream > "$raw/data/write-utf8-zstd-8k.json"
for name in binary-zstd-varlen binary-random-varlen; do
    extra=()
    if [[ $name == binary-random-varlen ]]; then extra+=(--random-bytes); fi
    "$main" -B "$tools/prepare.py" generate "$task/ipc/$name.arrow" 12000 65536 524288 "${extra[@]}"
    "$main" -B "$tools/prepare.py" write "$task/ipc/$name.arrow" "$task/p1/$name" --stream > "$raw/data/write-$name.json"
done
for name in utf8-1page utf8-zstd-25k utf8-zstd-8k binary-zstd-varlen binary-random-varlen binary-zstd-medium binary-medium-default mixed; do
    expectation=$archive/raw/pages-$name.json
    if [[ $name == binary-medium-default ]]; then expectation=$archive/resume/raw/pages-$name.json; fi
    check "p1-$name" "$task/p1/$name" "$expectation" "$main"
done
for name in wide-unique wide-unique-8k wide-low-card wide-repeated wide-template wide-clustered wide-mixed wide-constant narrow; do
    for variant in base final; do
        space
        path=$task/p2/$name/$variant
        mkdir -p "$(dirname "$path")"
        echo "$name $variant"
        if [[ $variant == final && ( $name == wide-repeated || $name == wide-clustered ) ]]; then
            ln -s "$reuse/$name" "$path"
            reader=$final
        else
            resolve "$variant"
            reader=$checkout/python/.venv/bin/python
            LANCE_BENCH_PROTO_DIR=$checkout/protos "$reader" -B "$prior/bench.py" measure "$old/$name.arrow" "$task" --writers 1 --file-stats --keep "$path" > "$raw/data/write-p2-$name-$variant.json"
        fi
        check "p2-$name-$variant" "$path" "$third/raw/phase2-pages-$name-$variant.json" "$reader"
    done
done
