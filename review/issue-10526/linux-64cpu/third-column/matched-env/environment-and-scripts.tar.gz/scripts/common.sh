#!/usr/bin/env bash
set -euo pipefail
disk=/root/lance/tmp/shared-buffer-matched-final
raw=$disk/raw
task=/dev/shm/lance-10526/shared-buffer-matched-final
tools=/root/lance/tmp/shared-buffer-tools
prior=/root/lance/tmp/10526-review/review/issue-10526/linux-64cpu
old=/dev/shm/lance-10526/ipc
reuse=/dev/shm/lance-10526/shared-buffer-followup/data
archive=/root/lance/tmp/review-fullzip-variable-shared-buffers/review/issue-10526
third=$prior/third-column
export LANCE_CPU_THREADS=64 TMPDIR=$disk/tmp UV_CACHE_DIR=/root/lance/cache/uv
unset LANCE_FILE_WRITER_MAX_PAGE_BYTES PYTHONPATH PYTHONHOME VIRTUAL_ENV
space() {
    df -h / /dev/shm >> "$raw/space.log"
    for mount in / /dev/shm; do (( $(df -B1 --output=avail "$mount" | tail -1) >= 10737418240 )); done
}
resolve() {
    case $1 in
        base) slot=00; checkout=/root/lance/base ;;
        pure) slot=01; checkout=/root/lance/shared-buffer-pure ;;
        final) slot=02; checkout=/root/lance/final ;;
        final-b) slot=03; checkout=/root/lance/shared-buffer-final ;;
    esac
    environment=$disk/env-$slot
    extension=$checkout/python/python/lance/lance.abi3.so
}
run() (
    resolve "$1"; shift
    cd "$disk"
    exec "$environment/bin/python" -B "$@"
)
